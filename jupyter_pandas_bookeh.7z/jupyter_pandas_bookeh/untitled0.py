# -*- coding: utf-8 -*-
"""
Created on Wed Mar 14 15:39:09 2018

@author: kate
"""

import bokeh
bokeh.__version__