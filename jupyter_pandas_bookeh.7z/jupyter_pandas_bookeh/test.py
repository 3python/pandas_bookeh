# -*- coding: utf-8 -*-
"""
Created on Wed Mar 14 15:39:12 2018

@author: kate
"""

#Import the pandas library.
import pandas

#Read in the csv file and create a dataframe.
#Index the rows by the name of the country column, opposed to row number.
df = pandas.read_csv('data/gapminder_gdp_europe.csv', index_col='country')
print(df)

from bokeh.io import output_file, show
from bokeh.plotting import figure

output_file('bums.html')
# create a new plot with default tools, using figure
p = figure(plot_width=400, plot_height=400)

# add a circle renderer with a size, color, and alpha
p.circle([1, 2, 3, 4, 5], [6, 7, 2, 4, 5], size=15, line_color="navy", fill_color="orange", fill_alpha=0.5)

show(p) # show the results

bokeh.__version__